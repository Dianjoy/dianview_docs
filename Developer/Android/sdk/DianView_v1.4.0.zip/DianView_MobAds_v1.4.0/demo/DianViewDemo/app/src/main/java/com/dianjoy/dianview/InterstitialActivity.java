package com.dianjoy.dianview;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.dianjoy.example.R;
import com.dianjoy.video.InterstitialAd;
import com.dianjoy.video.InterstitialAdListener;

public class InterstitialActivity extends Activity {
	
	String app_id = "3b85efd3eca8dab2";
	String placement_id = "d781772d02d29e6c46ea5ed58d368b4b902b9ddb";

	InterstitialAd ad;
	private static final String TAG = "DianViewDemo";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.content_interstitial);
		InterstitialAd.debug = true;
		ad = new InterstitialAd(this,app_id,placement_id);
		ad.setAdListener(new InterstitialAdListener() {
			@Override
			public void onAdReady() {
				Log.i(TAG,"onAdReady");
			}

			@Override
			public void onAdPresent() {
				Log.i(TAG,"onPresent");

			}

			@Override
			public void onAdClick() {
				Log.i(TAG,"onAdClick");

			}

			@Override
			public void onAdDismissed() {
				Log.i(TAG,"onAdDismissed");
			}

			@Override
			public void onAdFailed(String msg) {
				Log.i(TAG,"onAdFailed:"+msg);
			}
		});
	}

	public void handleClick(View view) {
		switch (view.getId()) {
			case R.id.load_xp:
				ad.loadAd();
				break;
			case R.id.xp_is_ready:
				boolean isReady = ad.isAdReady();
				Log.i(TAG, "isReady:" + isReady);
				break;
			case R.id.xp_show:
				ad.showAd(this);
				break;
		}
	}

}
