package com.dianjoy.dianview;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.dianjoy.example.R;
import com.dianjoy.video.DianViewAdManager;
import com.dianjoy.video.ScreenOrientationTpye;
import com.dianjoy.video.VideoAdListener;
import com.dianjoy.video.VideoAdPlayListener;
import com.dianjoy.video.VideoAvailableState;


public class VideoAdActivity extends Activity {
    private Button bt_init, bt_load, bt_checkAvailable,bt_play;
    private TextView tv_show;
    private static String LOG_TAG = "test";
    private static String app_id = "3b85efd3eca8dab2";
    private static String placement_id = "0c3aeeb1eb11513751fe27e75a05cda3b7835503";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_ad);
        bt_init = (Button) findViewById(R.id.bt_init);
        bt_load = (Button) findViewById(R.id.bt_load);
        bt_checkAvailable = (Button) findViewById(R.id.bt_checkAvailable);
        bt_play = (Button) findViewById(R.id.bt_play);
        tv_show = (TextView) findViewById(R.id.tv_show);
        bt_init.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DianViewAdManager.getInstance().init(VideoAdActivity.this, app_id, "");
            }
        });

        bt_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DianViewAdManager.getInstance().getVideoAdInstance(VideoAdActivity.this, placement_id).loadAd(new VideoAdListener() {
                    @Override
                    public void onVideoLoading() {
                        tv_show.setText("开始加载");
                        Log.i(LOG_TAG, "开始加载");
                    }

                    @Override
                    public void onVideoLoaded() {
                        tv_show.setText("加载完成");
                        Log.i(LOG_TAG, "加载完成");
                    }

                    @Override
                    public void onVideoLoadError(int errCode, String errMsg) {
                        tv_show.setText("加载失败：errCode-" + errCode + "  msg-" + errMsg);
                        Log.i(LOG_TAG,"加载失败：errCode-" + errCode + "  msg-" + errMsg);
                    }
                });
            }
        });

        bt_checkAvailable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int availableState = DianViewAdManager.getInstance().getVideoAdInstance(VideoAdActivity.this, placement_id).checkVideoAvailable();
                if (availableState == VideoAvailableState.NO_VIDEO_AD) {
                    tv_show.setText("广告状态：没有视频广告");
                } else if (availableState == VideoAvailableState.VIDEO_LOADED) {
                    tv_show.setText("广告状态：已有可播视频广告");
                } else if (availableState == VideoAvailableState.VIDEO_LOADING) {
                    tv_show.setText("广告状态：加载中");
                } else {
                    tv_show.setText("广告状态：其他");
                }
            }
        });

        bt_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DianViewAdManager.getInstance().getVideoAdInstance(VideoAdActivity.this,placement_id).play(ScreenOrientationTpye.AUTO, new VideoAdPlayListener() {
                    @Override
                    public void onVideoPlayBegin() {
                        Log.i(LOG_TAG, "开始播放");
                    }

                    @Override
                    public void onVideoPlayComplete() {
                        Log.i(LOG_TAG, "播放完成");
                    }

                    @Override
                    public void onVideoPlaySkip() {
                        Log.i(LOG_TAG, "跳过");
                    }

                    @Override
                    public void onVideoPlayError(int errCode, String errMsg) {
                        Log.i(LOG_TAG, "播放错误：errCode=" + errCode + "  errMsg=" + errMsg);
                    }

                    @Override
                    public void onVideoPlayAwardSuccess() {
                        Log.i(LOG_TAG, "奖励成功");
                    }

                    @Override
                    public void onVideoPlayAwardFail() {
                        Log.i(LOG_TAG, "奖励失败");
                    }

                    @Override
                    public void onVideoPlayClose() {
                        Log.i(LOG_TAG, "视频关闭");
                    }
                });
            }
        });



		if(Build.VERSION.SDK_INT >= 14){
			View decorVew = getWindow().getDecorView();
			int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
			decorVew.setSystemUiVisibility(uiOptions);
		}


	}


	private void showToast(final String msg){
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(VideoAdActivity.this,msg, Toast.LENGTH_SHORT).show();
			}
		});
	}


	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
    protected void onResume() {
        super.onResume();
    }
}
